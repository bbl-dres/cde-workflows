repo: bbl-dres/plan-check
branch: main

## Last sync
date: 2026-11-03T11:31:03Z

### Updated in this project
- Variante B «Grundmengen aus DWG» based on the plan-check workflow (one DWG per Geschoss, 40 rules per CAD-Richtlinie BBL V1.0)
- Rule codes, layers and AOID format taken from docs/anleitung-de.md and docs/pruefregeln-de.md

## Screen map
| Screen | Repo files |
|---|---|
| B1 Geschosse und Pläne | README.md, docs/anleitung-de.md |
| B2 Planprüfung pro Geschoss | docs/anleitung-de.md, docs/pruefregeln-de.md |
